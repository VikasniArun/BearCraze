import os, pygame
from pygame.locals import *
import time



if not pygame.font: print ('Warning, fonts disabled')
if not pygame.mixer: print ('Warning, sound disabled')

main_dir = os.path.split(os.path.abspath(__file__))[0]
data_dir = os.path.join(main_dir, 'images')

#functions to create our resources
def load_image(name, colorkey=None,scale=1):
    fullname = os.path.join(data_dir, name)
    try:
        image = pygame.image.load(fullname).convert_alpha()
        size=image.get_size()
        size=(size[0]*scale,size[1]*scale)
        image=pygame.transform.scale(image,size)
    except pygame.error:
        print ('Cannot load image:', fullname)
        raise SystemExit(str(geterror()))
    image = image.convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image, image.get_rect()

def load_sound(name):
    class NoneSound:
        def play(self): pass
    if not pygame.mixer or not pygame.mixer.get_init():
        return NoneSound()
    fullname = os.path.join(data_dir, name)
    try:
        sound = pygame.mixer.Sound(fullname)
    except pygame.error:
        print ('Cannot load sound: %s' % fullname)
        raise SystemExit(str(geterror()))
    return sound


#classes for our game objects

class Fist(pygame.sprite.Sprite):
    """moves a clenched fist on the screen, following the mouse"""
    def __init__(self):
        pygame.sprite.Sprite.__init__(self) #call Sprite initializer
        self.image, self.rect = load_image('fist5-removebg-preview.jpg',None,0.3)
        self.punching = 0

    def update(self):
        "move the fist based on the mouse position"
        pos = pygame.mouse.get_pos()
        self.rect.midtop = pos
        if self.punching:
            self.rect.move_ip(5, 10)

    def punch(self, target):
        "returns true if the fist collides with the target"
        if not self.punching:
            self.punching = 1
            hitbox = self.rect.inflate(-5, -5)
            return hitbox.colliderect(target.rect)

    def unpunch(self):
        "called to pull the fist back"
        self.punching = 0


class Bear(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        sprite_sheet, self.rect = load_image('spritesheet__3_-removebg-preview.png', None, 0.65)
        self.frames = []  
        self.cut_sheet(sprite_sheet, 6, 1)  
        
        # Initialize current_frame to 0 (the first frame)
        self.current_frame = 0  

        self.image = self.frames[self.current_frame]
        screen = pygame.display.get_surface()
        self.area = screen.get_rect()
        self.rect.topleft = 600, 400
        self.move = 3  
        self.dizzy = 0
        self.direction = -1
        self.pond = Rect(192, 300, 150, 150)

    # ... (rest of the class remains unchanged)


    def cut_sheet(self, sheet, columns, rows):
        frame_width = sheet.get_width() // columns
        frame_height = sheet.get_height() // rows

        target_width = int(self.rect.width * 0.8)
        target_height = int(self.rect.height * 4)

        for j in range(rows):
            for i in range(columns):
                frame_rect = pygame.Rect(i * frame_width, j * frame_height, frame_width, frame_height)
                frame = sheet.subsurface(frame_rect)

                frame = pygame.transform.flip(frame, True, False)
                frame = pygame.transform.smoothscale(frame, (target_width, target_height))

                frame.set_colorkey((0, 0, 0))

                self.frames.append(frame)

    def update(self):
        if self.dizzy:
            self._spin()
        else:
            self._walk()

    def _walk(self):
        """Move the bear across the screen and turn at the ends."""
        pond = self.pond

        # Calculate the new position before moving
        newpos = self.rect.move((self.move * self.direction, 0))

        # Check for collision with the pond or reaching the screen edges
        if newpos.colliderect(pond) or self.rect.right > self.area.right or self.rect.left < 0:
            # Change the direction
            self.direction *= -1

            # Flip the bear sprite horizontally
            self.image = pygame.transform.flip(self.image, True, False)

            # Update the new position after turning
            newpos = self.rect.move((self.move * self.direction, 0))


        # Update the bear's position with the new position
        self.rect = newpos

        # Update the bear's image with the current frame
        self.image = self.frames[self.current_frame]

        # Flip the bear sprite horizontally if moving in the opposite direction
        if self.direction == -1:
            self.image = pygame.transform.flip(self.image, True, False)

        # Cycle through frames for running animation
        frame_duration = 5  # Adjust frame duration for running animation
        if pygame.time.get_ticks() % frame_duration == 0:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
                
    def _spin(self):
        """Spin the bear image using the frames."""
        frame_duration = 5  # Adjust frame duration (lower values for faster animation)

        if pygame.time.get_ticks() % frame_duration == 0:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            frame1 = self.frames[self.current_frame]
            frame2 = self.frames[(self.current_frame + 1) % len(self.frames)]
            interpolation_factor = (pygame.time.get_ticks() % frame_duration) / frame_duration

            # Linear interpolation between frames
            interpolated_frame = lerp(frame1, frame2, interpolation_factor)
            
            # Rotate the interpolated frame
            angle = 180  # Adjust the rotation angle as needed
            self.image = pygame.transform.rotate(interpolated_frame, angle)
            
            center = self.rect.center
            self.rect = self.image.get_rect(center=center)

            

        # Check if spinning animation is complete
        if self.current_frame == 0:
            self.dizzy = 0  # Reset the dizzy state

        # Move the bear based on the current direction
        self.rect.move_ip((self.move, 0))



    def punched(self):
        """Start spinning animation when punched."""
        if not self.dizzy:
            self.dizzy = 1
            self.current_frame = 0  # Reset the current frame for spinning animation
            # Change the direction after being punched
            self.move = -abs(self.move) if self.move > 0 else abs(self.move)


# Helper function for linear interpolation between two surfaces
def lerp(surface1, surface2, alpha):
    result = pygame.Surface(surface1.get_size(), pygame.SRCALPHA)
    pygame.surfarray.blit_array(result, alpha * pygame.surfarray.array3d(surface1) + (1 - alpha) * pygame.surfarray.array3d(surface2))
    return result


class Fish(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image_water, self.rect = load_image("fish_in_water.png", None, 0.25)
        self.image_out_of_water, _ = load_image("fish_out_of_water.png", None, 0.25)
        self.original_water = self.image_water
        self.original_out_of_water = self.image_out_of_water
        self.rect.topleft = 10, 600
        self.is_jumping = False
        self.dizzy = 0
        self.image = self.image_water

    def update(self):
        if self.is_jumping:
            self.jump()
        else:
            self.spin()

    def spin(self):
        "spin the fish image"
        center = self.rect.center
        self.dizzy = (self.dizzy + 12) % 360  # Simplify the logic for looping
        rotate = pygame.transform.rotate
        self.image = rotate(self.original_water, self.dizzy)
        self.rect = self.image.get_rect(center=center)

    def jump(self):
        if self.is_jumping:  # Replace this condition with the actual condition for being out of water
            # Set the image to be out of water
            self.image = self.image_out_of_water
            newpos = self.rect.move(50, 50)  # Fix the syntax for moving
            self.rect = newpos
        else:
            # Set the image to be in water
            self.image = self.image_water

        
        #self.is_jumping = False



def show_instructions(screen):
    """Display instructions in a pop-up screen."""
    instruction_font = pygame.font.Font(None, 36)
    instructions = [
        "Instructions:",
        "1. Punch the bear by clicking the mouse.",
        "2. Press SPACE to make the fish jump.",
        "3. Avoid the bear colliding with the pond.",
        "4. Maximum limit: 1 minute.",
        "5. Have fun!",
    ]
    instruction_surface = pygame.Surface((400, 250), pygame.SRCALPHA)
    instruction_surface.fill((255, 255, 255, 200))  # Transparent white background

    y_offset = 20
    for line in instructions:
        text = instruction_font.render(line, True, (0, 0, 0))
        instruction_surface.blit(text, (20, y_offset))
        y_offset += 30

    screen.blit(instruction_surface, (400, 200))
    pygame.display.flip()
        
def main():
    """this function is called when the program starts.
       it initializes everything it needs, then runs in
       a loop until the function returns."""
#Initialize Everything
    pygame.init()
    screen = pygame.display.set_mode((1200,800), pygame.SRCALPHA)
    pygame.display.set_caption('Bear craze')
    pygame.mouse.set_visible(0)


#Create The Backgound
    width=1200
    height=800
    background=pygame.Surface(screen.get_size())
    bg_img = pygame.image.load("forest.jpg")
    bg_img = pygame.transform.scale(bg_img,(width,height))
    bg_img.convert()
    

#Put Text On The Background, Centered
    if pygame.font:
        X,Y=400,400
        font = pygame.font.Font(None, 52)
        text = font.render("Protect the fish", 1, (10, 10, 10))
        text2 = font.render("Maximum limit:1 minute", 1, (15, 15, 15))
        textpos=text.get_rect(centerx=background.get_width()/2)
        screen.blit(text,textpos)

#Display The Background


#Prepare Game Objects
    clock = pygame.time.Clock()
    whiff_sound = load_sound("punchmiss.mp3")
    punch_sound = load_sound('punch.mp3')
    splash_sound=load_sound("splash-6213.mp3")

    
    bear = Bear()
    fist = Fist()
    fish=Fish()
    allsprites = pygame.sprite.RenderPlain((fist,bear,fish))

    instructions_shown = False

    clock=pygame.time.Clock()
    
#Main Loop
    frame_count=0
    frame_rate=60
    start_tie=90
    going = True
    while going:
        clock.tick(60)
        screen.fill((0,0,0))
        total_seconds = frame_count // frame_rate
        frame_count+=1
    # Divide by 60 to get total minutes
        minutes = total_seconds // 60
 
    # Use modulus (remainder) to get seconds
        seconds = total_seconds % 60
 
    # Use python string formatting to format in leading zeros
        output_string = "Time: {0:02}:{1:02}".format(minutes, seconds)
 
    # Blit to the screen
        text1 = font.render(output_string, True, (0,0,0))
        textpos1=text1.get_rect(centerx=background.get_width()/2)
        screen.blit(text, [250, 250])
        screen.blit(text2, [270,270])

        

        #Handle Input Events
        for event in pygame.event.get():
            if event.type == QUIT:
                going = False
            elif event.type == KEYDOWN and event.key == K_ESCAPE:
                going = False
            elif event.type == MOUSEBUTTONDOWN:
                if fist.punch(bear):
                    punch_sound.play() #punch
                    bear.punched()
                else:
                    whiff_sound.play() #miss
            elif event.type == MOUSEBUTTONUP:
                fist.unpunch()
            elif event.type==K_SPACE:
                fish.jump()
                splash_sound.play()
            elif event.type == KEYDOWN and event.key == K_i:
                if not instructions_shown:
                    show_instructions(screen)
                    instructions_shown = True
                    
                    
        # Display instructions for 10 seconds
        if instructions_shown:
            show_instructions(screen)
            

        allsprites.update()

        #Draw Everything
        
        screen.blit(bg_img, (0, 0))
        screen.blit(text,textpos)
        screen.blit(text1,(50,50))
        if total_seconds>=60:
            going=False
    
        if total_seconds%5==0:
            pond=Rect(192,300,150,150)
            newpos = bear.rect.move((bear.move, 0))
            if pygame.Rect.colliderect(newpos,pond)==True:
                going=False
            splash_sound.play()
            screen.blit(fish.image,(50,400))
            
        
        allsprites.draw(screen)
        pygame.display.update()
    
    
    
    pygame.time.delay(5000)
    pygame.quit()
            
            

#Game Over


#this calls the 'main' function when this script is executed
if __name__ == '__main__':
    main()
print("GAME OVER")
